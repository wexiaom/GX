#!/system/bin/sh
#填H显示规则链
#填-T自定义iptables
#填-QQ放行QQ半免
#dns解析为-C勿动
#热点共享填-G

source $(dirname $0)/*/Soupr Yes -G -C

