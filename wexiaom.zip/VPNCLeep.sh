#VPN共享热点(Wi-Fi)
#
TPI="iptables"
SLeep() {
    $TPI -F
      M="-m state --state INVALID"
       $TPI -t nat -F PREROUTING
         $TPI -t nat -F POSTROUTING
          $TPI -t mangle -F PREROUTING
          $TPI -t mangle -P PREROUTING ACCEPT
         for U in wlan+ tun0;do
       $TPI -t nat -D OUTPUT -o $U -j ACCEPT
    $TPI -t nat -D INPUT -i $U -j ACCEPT
 done
}
case `$TPI -t nat -S|grep PREROUTING|grep -i 53` in
"") SLeep $*
echo " ✅ 已运行  📶VPN " > $(dirname $0)/Speed/VPN.ini
for O in PREROUTING;do
$TPI -t mangle -P $O DROP
$TPI -t mangle -I $O $M -j DROP
$TPI -t mangle -I $O -p all -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT;done
#-----------------
T="$TPI -t nat -A PREROUTING -s 192.168.0.0/16"
R="$TPI -t nat -A PREROUTING"
$T --protocol udp --dport 53 -j ACCEPT
$T --protocol udp ! --dport 53 -j DNAT --to 0
$T -m state --state ESTABLISHED,RELATED -j ACCEPT
$R -p tcp -m state --state ESTABLISHED,RELATED -j ACCEPT
$R -m state --state ESTABLISHED,RELATED -j ACCEPT
$TPI -t nat -A PREROUTING -m state --state ESTABLISHED -f -s 192.168/16 -d 192.168.43.1 -j DNAT --to 127.0.0.1
#-------------
for U in wlan+ tun0;do
$TPI -t nat -A OUTPUT -o $U -j ACCEPT
$TPI -t nat -A INPUT -i $U -j ACCEPT;done
#----------
ver=`getprop ro.build.version.release | grep 6.0`
if [[ $ver != "" ]];then
ip rule add iif ap0 lookup tun0
else
ip rule add iif wlan0 lookup tun0
fi
ip rule add uidrange 0-0 lookup local_network
$TPI -t nat -A POSTROUTING -o tun0 -j MASQUERADE
$TPI -t nat -A POSTROUTING -j MASQUERADE
;;*) SLeep $*
rm -rf $(dirname $0)/*/VPN.ini
;;esac
#
#
$(dirname $0)/Check.sh
#
#
#
#
