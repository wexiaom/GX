#!/system/bin/sh
#脚本运行耗时开始统计
 CM=$(date +%M)
  CS=$(date +%S)
 H=`date +"%k"`
M=꧁
echo "
`if [ ${H} -ge '0' -a ${H} -lt '5' ];then
echo " $M凌晨好"
elif [ ${H} -ge '5' -a ${H} -lt '8' ];then
echo " $M早晨好"
elif [ ${H} -ge '8' -a ${H} -lt '11' ];then
echo " $M上午好"
elif [ ${H} -ge '11' -a ${H} -lt '13' ];then
echo " $M中午时间"
elif [ ${H} -ge '13' -a ${H} -lt '16' ];then
echo " $M下午好"
elif [ ${H} -ge '16' -a ${H} -lt '19' ];then
echo " $M傍晚好"
elif [ ${H} -ge '19' -a ${H} -lt '24' ];then
echo " $M晚上好";fi`
⏩---------------------\n"
#写入执行次数
	if [[ -e "/data/rainytime.ini" ]];then
	 . /data/rainytime.ini
	       if [[ $rainytime != "" ]];then
	          rainytime=$rainytime
	       RAINYTIME=`expr $rainytime + 1`
	    else
	     RAINYTIME='1'
		fi
	else
     RAINYTIME='1'
    fi
     echo "rainytime='$RAINYTIME'" > /data/rainytime.ini
#
while read line
do
    [ -z "$line" ]&&break
    typeset -L17 netcard=${line##* }
    ip=${line%%/*}
for U in $netcard;do
case $U in
rmnet0) echo "🌸GPRS: "$netcard${ip##* };;
wlan0) echo "🌸WiFi: "$netcard${ip##* };;
tun0) echo "🌸VPN: " $netcard${ip##* };;esac
case $U in
rmnet0|wlan0|tun0) ui=`cat /proc/net/dev|grep -w $U|awk '{print $2}'`
sc=`cat /proc/net/dev|grep -w $U|awk '{print $10}'`
upn=`echo $(awk -v x=${ui} -v y=1048576 'BEGIN {printf "%.3f",x/y}')`
won=`echo $(awk -v x=${sc} -v y=1048576 'BEGIN {printf "%.3f",x/y}')`
ll=`echo $(awk -v x=${won} -v y=${upn} 'BEGIN {printf "%.3f",x+y}')`
echo "        消耗/${upn}M  传送/${won}M 总:${ll}M\n";;
esac;done
done <<EOF
`ip addr|grep global`
EOF
[ -n "$ip" ]&&echo
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄"
kjsj=`cat /proc/uptime`;kjsj=`echo ${kjsj%%.*}`
battery=`cat /sys/class/power_supply/battery/capacity` >/dev/null 2>&1
battery_mode=`cat /sys/class/power_supply/battery/charge_type` >/dev/null 2>&1
bb_ver=`busybox --help|head -1|cut -d "v" -f 2|cut -d " " -f 1`
ipt_ver=`iptables -V|cut -d "v" -f 2`
cswl=`getprop gsm.network.type|grep -i -v lte|grep -i -v fdd`
if [[ $battery_mode == "N/A" ]]
then echo "○当前电量:  $battery% `if [[ $battery -lt 15 ]] then echo "红色预警,少年赶快充电吧!";fi`"
else echo "○直流充电:  ⚡$battery%";fi
#脚本运行耗时结束统计
     BM=$(date +%M)
        BS=$(date +%S)
	       AMA=`expr $CM \* 60`
	          BMA=`expr $BM \* 60`
	       ASA=`expr $AMA + $CS`
	     BSA=`expr $BMA + $BS`
     A=`expr $BSA - $ASA`
	if [[ $A == "0" ]];then
	 A="1"
 fi
echo "○网络制式:  $cswl
○手机运行:  $(awk -v x=${kjsj} -v y=3600 'BEGIN {printf "%.1f",x/y}')时
○启动耗时： $A秒
○启动频率： $RAINYTIME次
○Iptables版本: $ipt_ver
`if [[ $bb_ver != "" ]];then
echo "○Busybox版本: $bb_ver ";else
echo "○Busybox不存在❌";fi`"
case `iptables -t nat -S|grep PREROUTING | grep -i udp` in
"") Sy=`echo "已停止  防火墙❌"`;;*) Sy=`echo "已运行  防火墙🔥";cat $(dirname $0)/*/VPN.ini`;;esac
echo "

"
H=`date +"%S"`
if [ ${H} -ge '0' -a ${H} -lt '2' ];then
echo "🎐人生如茶，粗品是苦的，细品是香的。"
elif [ ${H} -ge '2' -a ${H} -lt '4' ];then
echo "♥人生如月，残缺后终有圆满的到来。"
elif [ ${H} -ge '4' -a ${H} -lt '6' ];then
echo "🎐拥有梦想只是一种智力，实现梦想才是一种能力。"
elif [ ${H} -ge '6' -a ${H} -lt '8' ];then
echo "♥要铭记在心：每天都是一年中最美好的日子。"
elif [ ${H} -ge '8' -a ${H} -lt '10' ];then
echo "🎐人总是珍惜未得到的，而遗忘了所拥有的。"
elif [ ${H} -ge '10' -a ${H} -lt '12' ];then
echo "♥坚持意志伟大的事业需要始终不渝的精神.——伏尔泰"
elif [ ${H} -ge '12' -a ${H} -lt '14' ];then
echo "🎐内外相应,言行相称.——韩非"
elif [ ${H} -ge '14' -a ${H} -lt '16' ];then
echo "♥好的书籍是最贵重的珍宝.——别林斯基"
elif [ ${H} -ge '16' -a ${H} -lt '18' ];then
echo "🎐业精于勤,荒于嬉；行成于思,毁于随.——韩愈"
elif [ ${H} -ge '18' -a ${H} -lt '20' ];then
echo "♥普通人成功并非靠天赋，而是靠把寻常的天资发挥到不寻常的高度。"
elif [ ${H} -ge '20' -a ${H} -lt '22' ];then
echo "🎐只有面对现实，你才能超越现实。"
elif [ ${H} -ge '22' -a ${H} -lt '24' ];then
echo "♥内外相应,言行相称.——韩非"
elif [ ${H} -ge '24' -a ${H} -lt '26' ];then
echo "🎐形成天才的决定因素应该是勤奋.——郭沫若。"
elif [ ${H} -ge '26' -a ${H} -lt '28' ];then
echo "♥千里之行，始于足下。细节决定成败美丑"
elif [ ${H} -ge '28' -a ${H} -lt '30' ];then
echo "🎐我这个人走得很慢,但是我从不后退.——亚伯拉罕·林肯"
elif [ ${H} -ge '30' -a ${H} -lt '32' ];then
echo "♥谁和我一样用功,谁就会和我一样成功.——莫扎特"
elif [ ${H} -ge '32' -a ${H} -lt '34' ];then
echo "🎐勿问成功的秘诀为何,且尽全力做你应该做的事吧.——美华纳"
elif [ ${H} -ge '34' -a ${H} -lt '36' ];then
echo "♥普通人只想到如何度过时间,有才能的人设法利用时间.——叔本华"
elif [ ${H} -ge '36' -a ${H} -lt '38' ];then
echo "🎐一个人最大的破产是绝望，最大的资产是希望。"
elif [ ${H} -ge '38' -a ${H} -lt '40' ];then
echo "♥懒惰像生锈一样，比操劳更消耗身体。"
elif [ ${H} -ge '40' -a ${H} -lt '42' ];then
echo "🎐当一个人先从自己的内心开始奋斗，他就是个有价值的人。"
elif [ ${H} -ge '42' -a ${H} -lt '44' ];then
echo "♥一个人即使已登上顶峰,也仍要自强不息.——罗素·贝克"
elif [ ${H} -ge '44' -a ${H} -lt '46' ];then
echo "🎐自己活着,就是为了使别人过得更美好.——雷锋"
elif [ ${H} -ge '46' -a ${H} -lt '48' ];then
echo "♥只有永远躺在泥坑里的人,才不会再掉进坑里.——黑格尔"
elif [ ${H} -ge '48' -a ${H} -lt '50' ];then
echo "🎐希望的灯一旦熄灭,生活刹那间变成了一片黑暗.——普列姆昌德"
elif [ ${H} -ge '50' -a ${H} -lt '52' ];then
echo "♥只有永远躺在泥坑里的人,才不会再掉进坑里.——黑格尔"
elif [ ${H} -ge '52' -a ${H} -lt '54' ];then
echo "🎐人生如云，历经漂泊不定的旅行，终成甘露滋润世间万物。"
elif [ ${H} -ge '54' -a ${H} -lt '56' ];then
echo "♥常求有利别人，不求有利自己。"
elif [ ${H} -ge '56' -a ${H} -lt '58' ];then
echo "🎐只有把抱怨环境的心情,化为上进的力量,才是成功的保证.——罗曼·罗兰"
elif [ ${H} -ge '58' -a ${H} -lt '60' ];then
echo "♥勇猛、大胆和坚定的决心能够抵得上武器的精良.——达·芬奇";fi
echo " _______________________________________________
 ✅ $Sy
`for U in tiny Tiny Proxy Cproxy CProxy;do
ps|grep -qE "/$U?$" && \
echo " ✅ 已运行  $U";done`
                         
"
#echo "您的`curl ip.cn`"
exit 0
#꧁༺奔҉ั跑i҉ั҉͡҉҉ั҉

#☃️❀.*･ﾟ
#
