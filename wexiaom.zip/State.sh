#!/system/bin/sh
DIR="$( cd "$( dirname "$0" )" && pwd )"
source $DIR/*/*.conf
case `iptables -t nat -S|grep OUTPUT|grep -i UID` in
"") Go=`echo " 【No❌】"`;;*) Go=`echo "【 Yes🔥】"`;;esac
jo=`ip addr|awk '/(inet)(.*)(global)(.*)(\w{5})(0)$/{printf $5}'`
Ip=`ip addr show ${jo}|awk '/'${jo}'$/{printf $2}'|awk -F '/' '{printf $1}'`
wifi=`getprop wifi.interface`;ws=`ip addr show ${wifi}|awk '/'${wifi}'$/{printf $2}'|awk -F '/' '{printf $1}'`
#----------------------
if [ $jo != "" ];then
S="\n  ⏩随机内网 : $jo $Ip\n"
xj=`cat /proc/net/dev|grep -w $jo|awk '{print $2}'`
sj=`cat /proc/net/dev|grep -w $jo|awk '{print $10}'`
u=`echo $(awk -v x=${xj} -v y=1048576 'BEGIN {printf "%.3f",x/y}')`
n=`echo $(awk -v x=${sj} -v y=1048576 'BEGIN {printf "%.3f",x/y}')`
GPRS=`echo "$S  ⏩本地数据 : ${u}MB/使用 ${n}MB/发送 "`;fi
#-----Wi-Fi
if [ $ws != "" ];then
ui=`cat /proc/net/dev|grep -w $wifi|awk '{print $2}'`
sc=`cat /proc/net/dev|grep -w $wifi|awk '{print $10}'`
upn=`echo $(awk -v x=${ui} -v y=1048576 'BEGIN {printf "%.2f",x/y}')`
won=`echo $(awk -v x=${sc} -v y=1048576 'BEGIN {printf "%.2f",x/y}')`
ki=`echo "\n  ⏩热点数据 : ${won}MB/消耗 ${upn}MB/收发"`;fi
H=`date +"%k"`
M=`date +"%l:%M"`
if [ ${H} -ge '0' -a ${H} -lt '5' ];then
so="🎐 凌晨好"
elif [ ${H} -ge '5' -a ${H} -lt '8' ];then
so="🎐 早晨好"
elif [ ${H} -ge '8' -a ${H} -lt '11' ];then
so="🎐 上午好"
elif [ ${H} -ge '11' -a ${H} -lt '13' ];then
so="🎐 中午好"
elif [ ${H} -ge '13' -a ${H} -lt '16' ];then
so="🎐 下午好"
elif [ ${H} -ge '16' -a ${H} -lt '19' ];then
so="🎐 傍晚好"
elif [ ${H} -ge '19' -a ${H} -lt '24' ];then
so="🎐 晚上好";fi

echo
printf " "
printf "%-15s%-14s%-12s%-14s\n" "  进程名字" "  用户组" " 进程ID" "内存大小"
for U in Proxy Tiny ./HaP tdnsp Tdns Samp Snsp pdnsd;do
if [[ `pgrep $U` != "" ]];then
printf "   %-9s%" " ${U}"
printf "%-10s%-9s%-11s\n" `ps|grep -i "${U}"|tail -n 1|awk '{print $1" "$2" "$5"KB"}'`
#break
fi
done
#------------------
port=$listen_port
TCPListeningnum=`netstat -an | grep ":$port " | awk '$1 == "tcp" && $NF == "LISTEN" {print $0}' | wc -l`
if [ $TCPListeningnum = 1 ]
then
{
   Port="【$port】"
}
else
{
    Port="【™null】"
}
fi
#---------------

case $MDNS in
dns)
udp_Port="$dns_listen_port";;
dnsp) udp_Port="10053";;
dnst) udp_Port="50053";;
dnsj) udp_Port="60053";;
dnsz) udp_port="1133";;esac
UDPLisre=`netstat -an | grep ":$udp_Port" | awk '$1 == "udp" && $5 == "0.0.0.0:*" {print $0}' | wc -l`
if [ $UDPLisre = 1 ]
then
{
   udp_Port="【$udp_Port】"
}
else
{
   udp_Port="【™null】"
}
fi
echo "\n                                 
     TCP监听      UDP监听      防火墙
    $Port    $udp_Port   $Go\n
 ────────────────────────

   $so\n    -------\n
  ⏩无线网络 : $wifi $ws$GPRS$ki
  \n         
                            🌸
    🌸　　　　 ✨
　　　　　　　　　　　　
　　　　　　　　　僕　花　あ 今
　　　　　　　知　達　の　の 宵  
　　　　　　　ら　は　名　日 醉
　　　　　　　な　ま　前　見 红　
　　　　　　　ぃ　だ　を　た 颜　
　　　　　　　　。       🌠
　　　　　　 🌸　${M}"
exit 0
#
#
