
svc data disable

pkill pdnsd
pkill redsocks
pkill ss-local
iptables -t nat -F PREROUTING
iptables -t nat -F OUTPUT
iptables -t mangle -F INPUT
iptables -t mangle -F OUTPUT
iptables -t mangle -F FORWARD
iptables -t mangle -P INPUT ACCEPT
iptables -t mangle -P OUTPUT ACCEPT
iptables -t mangle -P FORWARD ACCEPT