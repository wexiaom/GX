echo "  "
for u in ss-local redsocks pdnsd;do
if [[ `ps|grep -i $u` != "" ]]
then
echo " ● 已启用 $u"
else
echo " ○ 已停用 $u"
fi
echo "  ";done
echo "→ nat表 ←"
iptables -t nat -nL OUTPUT --line-numbers
iptables -t nat -nL PREROUTING --line-numbers
echo "  "
echo "→ mangle表 ←"
iptables -t mangle -nL INPUT --line-numbers
iptables -t mangle -nL OUTPUT --line-numbers
iptables -t mangle -nL FORWARD --line-numbers